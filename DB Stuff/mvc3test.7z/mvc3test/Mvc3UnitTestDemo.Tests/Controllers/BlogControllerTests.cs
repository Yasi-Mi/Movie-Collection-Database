﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Mvc3UnitTestDemo.Models;
using Moq;
using Mvc3UnitTestDemo.Controllers;
using System.Web.Mvc;
namespace Mvc3UnitTestDemo.Tests.Controllers
{
    /// <summary>
    /// Summary description for BlogControllerTests
    /// </summary>
    [TestClass]
    public class BlogControllerTests
    {
        [TestInitialize]
        public void TestFixtureSetUp()
        {
            //store = 1; //in MSTest this is called per test, in NUnit, once per class
        }
        public BlogControllerTests()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext{get;set;}

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Test_Recent()
        {
            //Arrange
            var posts = new List<Post>();
            posts.Add(new Post());
            posts.Add(new Post());

            var repository = new Mock<IPostRepository>();
            repository.Setup(r => r.ListRecentPosts(It.IsAny<int>())).Returns(posts);

            //Act
            BlogController controller = new BlogController(repository.Object);
            var result = controller.Recent() as ViewResult;

            //Assert
            var model = result.ViewData.Model as IList<Post>;
            Assert.AreEqual(2, model.Count);
        }
    }
}
