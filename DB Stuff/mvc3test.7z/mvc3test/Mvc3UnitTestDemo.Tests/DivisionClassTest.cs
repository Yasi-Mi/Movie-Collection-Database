﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Mvc3UnitTestDemo.Tests
{
    [TestClass]
    public class DivisionClassTest
    {
        public DivisionClassTest()
        {
        }
        public TestContext TestContext { get; set; }

        [TestMethod()]
        [ExpectedException(typeof(System.DivideByZeroException))]
        public void DivideTest()
        {
            DivisionClass target = new DivisionClass();
            int numerator = 4;
            int denominator = 0;
            int actual;
            actual = target.Divide(numerator, denominator);
        }
    }
}
