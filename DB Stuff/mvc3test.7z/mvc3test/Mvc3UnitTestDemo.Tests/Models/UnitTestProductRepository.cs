﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Mvc3UnitTestDemo.Models;
using Moq;
namespace Mvc3UnitTestDemo.Tests.Models
{
    /// <summary>
    /// Summary description for UnitTestProductRepository
    /// </summary>
    [TestClass]
    public class UnitTestProductRepository
    {
        public UnitTestProductRepository()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        //public  IProductRepository MockProductsRepository;
        //[TestInitialize]
        //public void MyTestInitialize()
        //{
        //    this.context = new NorthwindEntities();
        //}
        ////Use TestCleanup to run code after each test has run
        //[TestCleanup]
        //public void MyTestCleanup()
        //{
        //    this.context.Dispose();
        //}
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext{get;set;}

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void Test_FindByName_GetCalled()
        {
            // create some mock products to play with
            IList<Product> products = new List<Product>
                {
                    new Product { ProductId = 1, Name = "C# Unleashed",
                        Description = "Short description here", Price = 49.99 },
                    new Product { ProductId = 2, Name = "ASP.Net Unleashed",
                        Description = "Short description here", Price = 59.99 },
                    new Product { ProductId = 3, Name = "Silverlight Unleashed",
                        Description = "Short description here", Price = 29.99 }
                };
            Mock<IProductRepository> mock = new Mock<IProductRepository>();
            //mock
            //    .Setup(sender => sender.FindById(It.IsAny<int>()))
            //    .Returns((int s) => products.Where(
            //        x => x.ProductId == s).Single());
            mock.Object.FindById(1);
            mock
                .Verify(x => x.FindById(1), Times.Once());
        }
        //[TestMethod]
        //[ExpectedException(typeof(ArgumentOutOfRangeException))]
        //public void MyTestMethod()
        //{
        //    IList<Product> products = new List<Product>
        //        {
        //            new Product { ProductId = 1, Name = "C# Unleashed",
        //                Description = "Short description here", Price = 49.99 },
        //            new Product { ProductId = 2, Name = "ASP.Net Unleashed",
        //                Description = "Short description here", Price = 59.99 },
        //            new Product { ProductId = 3, Name = "Silverlight Unleashed",
        //                Description = "Short description here", Price = 29.99 }
        //        };
        //    Mock<IProductRepository> mock = new Mock<IProductRepository>();
        //    mock
        //        .Setup(sender => sender.FindById(It.IsAny<int>()))
        //        .Throws(new ArgumentOutOfRangeException());
           
        //}

    }
}
