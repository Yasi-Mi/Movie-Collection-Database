﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Mvc3UnitTestDemo.Models;
namespace Mvc3UnitTestDemo.Tests.Models
{
    /// <summary>
    /// Summary description for EmployeeUnitTest
    /// </summary>
    [TestClass]
    public class EmployeeUnitTest
    {
        public EmployeeUnitTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {get;set;}

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

    //1. Basic usage test
        [TestMethod]
        public void Existing_Specified_Employee_Test()
        {
            var newEmployee = new Mock<IEmployee>();
            newEmployee.SetupGet(e =>e.Id).Returns(1);
            newEmployee.SetupGet(e => e.Title).Returns("Chief Editor");

            Assert.AreEqual("Chief Editor", newEmployee.Object.Title);
        }
        [TestMethod]
        public void GetTest()
        {
            //Arrange
            var newEmployee = new Mock<IEmployee>();
            newEmployee.SetupGet(e => e.Title).Returns("Chief Editor");
            var empRepository = new Mock<IEmployeeRepository>();
            empRepository.Setup(e => e.Get(1))
              .Returns(newEmployee.Object);

            // Act
            var empReturned = empRepository.Object.Get(1);
            // Assert
            Assert.AreEqual("Chief Editor", empReturned.Title);
        }
        [TestMethod]
        public void GetTest2()
        {
            //Arrange
            var newEmployee = new Mock<IEmployee>();
            newEmployee.SetupGet(e => e.Title).Returns("Chief Editor");
            var empRepository = new Mock<IEmployeeRepository>();
            empRepository.Setup(e => e.Get(It.IsAny<int>()))
              .Returns(newEmployee.Object);

            // Act
            var empReturned = empRepository.Object.Get(5);
            // Assert
            Assert.AreEqual("Chief Editor", empReturned.Title);
        }
        [TestMethod]
        public void GetTest3()
        {
            //Arrange
            var newEmployee = new Mock<IEmployee>();
            newEmployee.SetupGet(e => e.Title).Returns("Chief Editor");
            var empRepository = new Mock<IEmployeeRepository>();
            empRepository.Setup(e => e.Get(It.Is<int>(id=>id>0 && id<10)))
              .Returns(newEmployee.Object);

            // Act
            var empReturned = empRepository.Object.Get(15);
            // Assert
            Assert.AreEqual("Chief Editor", empReturned.Title);
        }

        //define the test method
        [TestMethod]
        public void Test_Interface_IFake()
        {
            //make a mock Object by Moq
            var mo = new Mock<IFake>();
            //Setup our mock object
            mo
            .Setup(foo => foo.DoSomething("Ping"))
            .Returns(true);
            //Assert it!
            Assert.AreEqual(true, mo.Object.DoSomething("Ping"));
        }

        [TestMethod]
        public void User_Can_Send_Password()
        {
            var emailMock = new Moq.Mock<IEmailSender>();
            emailMock
            .Setup(sender => sender.Send(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()))
            .Returns(true);
        }

        [TestMethod]
        public void MyTestMethod()
        {
            var mock = new Mock<IFake>(MockBehavior.Strict);
        }

    }
}
