﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Web.Mvc;
using System.Web.Routing;
using Moq;
using System.Web;
using System.Collections.Specialized;
namespace Mvc3UnitTestDemo.Tests
{
    /// <summary>
    /// Summary description for RoutesUnitTest
    /// </summary>
    [TestClass]
    public class RoutesUnitTest
    {
        public RoutesUnitTest()
        {
        }
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext{get;set;}
        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        [TestMethod]
        public void TestCertainRoute()
        {
            var routes = new RouteCollection();
            MvcApplication.RegisterRoutes(routes);
            var mockHttpContext = MakeMockHttpContext("~/");
            RouteData routeData = routes.GetRouteData(mockHttpContext.Object);
            Assert.IsNotNull(routeData, "NULL RouteData was returned");
            //other related assertions…
        }
        private static Mock<HttpContextBase> MakeMockHttpContext(string url)
        {
            var mockHttpContext = new Mock<HttpContextBase>();

            // Mock the request
            var mockRequest = new Mock<HttpRequestBase>();
            mockHttpContext.Setup(x => x.Request).Returns(mockRequest.Object);
            mockRequest.Setup(x => x.AppRelativeCurrentExecutionFilePath).Returns(url);

            // Mock the response
            var mockResponse = new Mock<HttpResponseBase>();
            mockHttpContext.Setup(x => x.Response).Returns(mockResponse.Object);
            mockResponse.Setup(x => x.ApplyAppPathModifier(It.IsAny<string>()))
            .Returns<string>(x => x);
            return mockHttpContext;
        }
        //outbound route test 1
        [TestMethod]
        public void Edit_Products_ID_10_Test()
        {
            string result = SetupUrlViaMocks(
            new { controller = "Products", action = "Edit", id = 10 }
            );
            Assert.AreEqual("/Products/Edit/10", result);
        }
        private string SetupUrlViaMocks(object values)
        {
            // Arrange (get the routing config and test context)
            RouteCollection routeConfig = new RouteCollection();
            MvcApplication.RegisterRoutes(routeConfig);
            var mockContext = MakeMockHttpContext(null);
            RequestContext context = new RequestContext(mockContext.Object, new RouteData());
            // Act (generate a URL)
            return UrlHelper.GenerateUrl(null, null, null,
            new RouteValueDictionary(values), routeConfig, context, true);
        }

        [TestMethod]
        public void ActionWithAmbientControllerSpecificAction()
        {
            UrlHelper helper = GetUrlHelper();
            string url = helper.Action("action");
            Assert.AreEqual("/defaultcontroller/action", url);
        }
        static UrlHelper GetUrlHelper(string appPath = "/", RouteCollection routes = null)
        {
            if (routes == null)
            {
                routes = new RouteCollection();
                MvcApplication.RegisterRoutes(routes);
            }
            HttpContextBase httpContext = new StubHttpContextForRouting(appPath);
            RouteData routeData = new RouteData();
            routeData.Values.Add("controller", "defaultcontroller");
            routeData.Values.Add("action", "defaultaction");
            RequestContext requestContext = new RequestContext(httpContext, routeData);
            UrlHelper helper = new UrlHelper(requestContext, routes);
            return helper;
        }
        public class StubHttpContextForRouting : HttpContextBase
        {
            StubHttpRequestForRouting _request;
            StubHttpResponseForRouting _response;

            public StubHttpContextForRouting(string appPath = "/", string requestUrl = "~/")
            {
                _request = new StubHttpRequestForRouting(appPath, requestUrl);
                _response = new StubHttpResponseForRouting();
            }
            public override HttpRequestBase Request
            {
                get { return _request; }
            }
            public override HttpResponseBase Response
            {
                get { return _response; }
            }
        }

        public class StubHttpRequestForRouting : HttpRequestBase
        {
            string _appPath;
            string _requestUrl;

            public StubHttpRequestForRouting(string appPath, string requestUrl)
            {
                _appPath = appPath;
                _requestUrl = requestUrl;
            }
            public override string ApplicationPath
            {
                get { return _appPath; }
            }
            public override string AppRelativeCurrentExecutionFilePath
            {
                get { return _requestUrl; }
            }
            public override string PathInfo
            {
                get { return ""; }
            }
            public override NameValueCollection ServerVariables
            {
                get { return new NameValueCollection(); }
            }
        }

        public class StubHttpResponseForRouting : HttpResponseBase
        {
            public override string ApplyAppPathModifier(string virtualPath)
            {
                return virtualPath;
            }
        }

    }
}
