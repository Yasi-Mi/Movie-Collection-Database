﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Mvc3UnitTestDemo.Tests
{
    /// <summary>
    /// Summary description for ThingTests
    /// </summary>
    [TestClass]
    public class ThingTests
    {
        public TestContext TestContext { get; set; }
        // A simple field that we're going to initialize to 
        // some value in the Initialize method.  
        private string _thing;

        public ThingTests(){}

        [TestInitialize]
        public void MyInitialize()
        {
            // Obviously we could do something much more complex here.
            if (TestContext.Properties.Contains("thing"))
            {
                _thing = TestContext.Properties["thing"] as string;
            }
            else
            {
                _thing = "default";
            }
        }
        [TestMethod]
        public void TestAgainstDefaultSetup()
        {
            Assert.AreEqual("default", _thing);
        }
        [TestMethod]
        [TestProperty("thing", "non-default")]
        public void TestAgainstCustomSetup()
        {
            Assert.AreEqual("non-default", _thing);
        }
    }
}
