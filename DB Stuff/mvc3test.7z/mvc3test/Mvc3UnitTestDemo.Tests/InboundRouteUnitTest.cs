﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Web.Routing;//RouteCollection
using System.Web;//HttpContextBase
using Moq;
using System.Collections.Specialized;//NameValueCollection
namespace Mvc3UnitTestDemo.Tests
{
    /// <summary>
    /// Summary description for InboundRouteUnitTest
    /// </summary>
    [TestClass]
    public class InboundRouteUnitTest
    {
        public InboundRouteUnitTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion

        //[TestMethod]
        //public void TestSomeRoute()
        //{
        //    // Arrange (obtain routing config + set up test context)
        //    RouteCollection routeConfig = new RouteCollection();
        //    MvcApplication.RegisterRoutes(routeConfig);
        //    HttpContextBase testContext = Need to get an instance somehow
        //    // Act (run the routing engine against this HttpContextBase)
        //    RouteData routeData = routeConfig.GetRouteData(testContext);
        //    // Assert
        //    Assert.IsNotNull(routeData, "NULL RouteData was returned");
        //    Assert.IsNotNull(routeData.Route, "No route was matched");
        //    // Add other assertions to test that this is the right RouteData        
        //}
        [TestMethod]
        public void TestSomeRoute()
        {
            // Arrange (obtain routing config + set up test context)
            var routes = new RouteCollection();
            MvcApplication.RegisterRoutes(routes);
            var mockHttpContext = SetupMockHttpContext("~/");
            // Act (run the routing engine against this HttpContextBase)
            RouteData routeData = routes.GetRouteData(mockHttpContext.Object);
            // Assert
            Assert.IsNotNull(routeData, "NULL RouteData was returned");
            Assert.IsNotNull(routeData.Route, "No route was matched");
            Assert.AreEqual("Home", routeData.Values["controller"], "Wrong controller");
            Assert.AreEqual("Index", routeData.Values["action"], "Wrong action");
        }

        private static Mock<HttpContextBase> SetupMockHttpContext(string url)
        {
            //Mock the HTTP context
            var mockHttpContext = new Mock<HttpContextBase>();
            // Mock the request
            var mockRequest = new Mock<HttpRequestBase>();
            // Mock the response
            var mockResponse = new Mock<HttpResponseBase>();

            mockHttpContext.Setup(x => x.Request).Returns(mockRequest.Object);
            mockRequest.Setup(x => x.AppRelativeCurrentExecutionFilePath).Returns(url);

            mockHttpContext.Setup(x => x.Response).Returns(mockResponse.Object);
            mockResponse.Setup(x => x.ApplyAppPathModifier(It.IsAny<string>()))
            .Returns<string>(x => x);
            return mockHttpContext;
        }
        //the test double utility class
        public class TestHttpContext : HttpContextBase
        {
            TestHttpRequest testRequest;
            TestHttpResponse testResponse;
            public override HttpRequestBase Request { get { return testRequest; } }
            public override HttpResponseBase Response { get { return testResponse; } }
            public TestHttpContext(string url)
            {
                testRequest = new TestHttpRequest()
                {
                    _AppRelativeCurrentExecutionFilePath = url
                };
                testResponse = new TestHttpResponse();
            }
            class TestHttpRequest : HttpRequestBase
            {
                public string _AppRelativeCurrentExecutionFilePath { get; set; }
                public override string AppRelativeCurrentExecutionFilePath
                {
                    get { return _AppRelativeCurrentExecutionFilePath; }
                }
                public override string ApplicationPath { get { return null; } }
                public override string PathInfo { get { return null; } }
                public override NameValueCollection ServerVariables
                {
                    get { return null; }
                }
            }
            class TestHttpResponse : HttpResponseBase
            {
                public override string ApplyAppPathModifier(string x) { return x; }
            }
        }
        [TestMethod]
        public void ForwardSlashGoesToHomeIndex()
        {
            // Arrange (obtain routing config + set up test context)
            RouteCollection routeConfig = new RouteCollection();
            MvcApplication.RegisterRoutes(routeConfig);
            HttpContextBase testContext = new TestHttpContext("~/");
            // Act (run the routing engine against this HttpContextBase)
            RouteData routeData = routeConfig.GetRouteData(testContext);
            // Assert
            Assert.IsNotNull(routeData, "NULL RouteData was returned");
            Assert.IsNotNull(routeData.Route, "No route was matched");
            Assert.AreEqual("Home", routeData.Values["controller"], "Wrong controller");
            Assert.AreEqual("Index", routeData.Values["action"], "Wrong action");
        }

    }
}
