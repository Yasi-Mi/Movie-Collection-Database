﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mvc3UnitTestDemo.Tests
{
    class DivisionClass
    {
        public int Divide(int numerator, int denominator)
        {
            return numerator / denominator;
        }
    }
}
