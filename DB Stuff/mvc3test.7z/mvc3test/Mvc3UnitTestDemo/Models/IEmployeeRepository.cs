﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Mvc3UnitTestDemo.Models
{
    public interface IEmployeeRepository
    {
        List<IEmployee> Select();
        IEmployee Get(int id);
    }

    public interface IEmployee
    {
        int Id { get; set; }
        string FirstName { get; set; }
        string LastName { get; set; }
        string Title { get; set; }
    }

    //define interface to be mocked
    public interface IFake
    {
        bool DoSomething(string actionname);
    }
    public interface IEmailSender
    {
        bool Send(string subject, string body, string email);
    }

}