﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Mvc3UnitTestDemo.Models
{
    public class Post
    {
        public string Title { get; set; }
        public string Time { get; set; }
        public string Description { get; set; }
    }
}