﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Mvc3UnitTestDemo.Models
{
    public interface IPostRepository
    {
        void Create(Post post);
        IList<Post> ListRecentPosts(int retrievalCount);
    }
    public class InMemoryPostRepository : IPostRepository
    {
        private static IList<Post> posts = new List<Post>();
        public static void Clear()
        {
            posts.Clear();
        }

        #region IPostRepository Members
        void IPostRepository.Create(Post post)
        {
            posts.Add(post);
        }
        IList<Post> IPostRepository.ListRecentPosts(int retrievalCount)
        {
            if (retrievalCount < 0)
                throw new ArgumentOutOfRangeException("retrievalCount"
                    , "The argument out of valid range!");

            IList<Post> recent = new List<Post>();
            int recentIndex = posts.Count - 1;
            for (int i = 0; i < retrievalCount; i++)
            {
                if (recentIndex < 0)
                    break;
                recent.Add(posts[recentIndex--]);
            }
            return recent;
        }
        #endregion
    }
}