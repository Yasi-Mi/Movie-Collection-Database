﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Ninject;

namespace Mvc3UnitTestDemo
{
    public class NinjectDependencyResolver : IDependencyResolver
    {
        #region IDependencyResolver 成员

        /// <summary>
        /// 依赖注入核心模块
        /// </summary>
        private IKernel _kernel;

        /// <summary>
        /// 构造
        /// </summary>
        /// <param name="aKernel">依赖注入核心</param>
        public NinjectDependencyResolver(IKernel aKernel)
        {
            _kernel = aKernel;
        }

        public object GetService( Type aServiceType )
        {
            try
            {
                return _kernel.Get(aServiceType);
            }
            catch
            {
                /// 按微软的要求，此方法，在没有解析到任何对象的情况下，必须返回 null，必须这么做！！！！
                return null;
            }
        }

        public IEnumerable<object> GetServices( Type aServiceType )
        {
            try
            {
                return _kernel.GetAll(aServiceType);
            }
            catch
            {
                /// 按微软的要求，此方法，在没有解析到任何对象的情况下，必须返回空集合，必须这么做！！！！
                return new List<object>( );
            }
        }
        #endregion
    }

}