﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mvc3UnitTestDemo
{
    public class MiniCalculator
    {
        private float Add(float op1, float op2)
        {
            return op1 + op2;
        }
        //...other memebers omitted
    }
}
