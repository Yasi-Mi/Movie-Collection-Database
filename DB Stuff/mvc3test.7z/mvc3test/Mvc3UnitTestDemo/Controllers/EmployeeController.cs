﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mvc3UnitTestDemo.Controllers
{
    public class EmployeeController
    {
        public void Details(int? EmployeeID)
        {
            throw new ArgumentNullException("EmployeeID");
        }
    }
}
