﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Mvc3UnitTestDemo.Models;
using Ninject;
namespace Mvc3UnitTestDemo.Controllers
{
    public class BlogController : Controller
    {
        IPostRepository repository;

        //[Inject]
        public BlogController(IPostRepository repository)
        {
            this.repository = repository;
        }
        public ActionResult Recent()
        {
            IList<Post> posts = repository.ListRecentPosts(10);
            return View(posts);
        }
        public ActionResult Index()
        {
            return View();
        }
    }
}
