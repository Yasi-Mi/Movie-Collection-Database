﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Mvc3UnitTestDemo
{
    public class StaticMethod
    {
        public static int add(int d1,int d2)
        {
            return d1 + d2;
        }
    }
}