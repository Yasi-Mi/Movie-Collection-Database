﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Mvc3UnitTestDemo
{
    public class Class1
    {
        private int Method1(int a, int b)
        {
            return a + b;
        }
    }
}