﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using Ninject.Modules;
using Ninject;


using System.Web.Mvc;
using Mvc3UnitTestDemo.Models;
using System.Configuration;
namespace Mvc3UnitTestDemo
{
    public class NinjectControllerFactory : DefaultControllerFactory
    {
        private IKernel _kernel = new StandardKernel(new MyModule());
        protected override IController GetControllerInstance(System.Web.Routing.RequestContext requestContext, Type controllerType)
        {
            if (controllerType == null)
                return null;
            return (IController)_kernel.Get(controllerType);
        }
        private class MyModule : NinjectModule
        {
            public override void Load()
            {
                Bind<IPostRepository>()
                    .To<InMemoryPostRepository>().InRequestScope();

                //实战中
                //Bind<IProductsRepository>()
                //    .To<SqlProductsRepository>()
                //    .WithConstructorArgument("connectstring", ConfigurationManager.ConnectionStrings["TestDb"].ConnectionString);
            }
        }
    }
}